from adversarial_transformation import *
from image_classification import *

if __name__ == "__main__":
    # the default path of the image is ../data/images/cat.jpeg. The adversarial function takes the image and produces
    # the adv_image = image + perturbation. The adversarial image is then saved into ../data/images/adversarial.png
    # the other parameter of the adversarial function is epsilon
    adversarial(epsilon=0.01)
    # image classification takes the adversarial image and computes the classification with YOLO
    image_classification()